angular.module("portal").constant("config", {
	baseUrl: "http://localhost:8000",
        //baseUrl: "http://api.webdentalsolucoes.com.br",
        //baseUrl: "192.168.15.22:8000",
        baseUrlPublic: "http://localhost/admin/public/"
        
});